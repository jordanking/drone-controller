# drone-controller

Drone wars programs:

adattacker:
    listens for packets to drone (besides our dos script) and replaces the load (forging ip and macs) with a land command
adddos:
    vomits packets at the drone ip
adcontroller:
    controls drone, can hold s to flood network with fake commands and drone feedback to hide our ip/mac

Annie Barbeau
Marc Hosecloth
Jeffery Tso
Jordan King
Emma Phillips